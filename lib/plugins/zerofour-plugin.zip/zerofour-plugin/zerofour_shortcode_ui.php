<?php

	/* ----------------------------------------------------------- */
	/* Add UI button for button shortcode in shortcake UI plugin */
	/* ------------------------------------------------------------ */
	function zerofour_btn_shortcode_reg() {
		$fields	= array(
			array(
				'label'			=> __( 'Button Text', 'zerofour' ),
				'description' 	=> esc_html__( 'You can enter the button text here.', 'zerofour' ),
				'attr'			=> 'text',
				'type'			=> 'text'
			),
			array(
				'label'			=> __( 'Icon Name', 'zerofour' ),
				'description' 	=> esc_html__( 'You can enter the font-awesome icon name here. (e.g. fa-info-circle)', 'zerofour' ),
				'attr'			=> 'icon',
				'type'			=> 'text'
			),
			array(
				'label'			=> __( 'Button URL', 'zerofour' ),
				'description' 	=> esc_html__( 'You can enter the url here. (e.g. http://example.com)', 'zerofour' ),
				'attr'			=> 'url',
				'type'			=> 'text'
			),
			array(
				'label'			=> __( 'Button Target', 'zerofour' ),
				'attr'			=> 'target',
				'type'			=> 'select',
				'options'		=> array(
					'_self'		=> __( '_self', 'zerofour' ),
					'_blank'	=> __( '_blank', 'zerofour' )
				)
			),
			array(
				'label'			=> __( 'Button Color', 'zerofour' ),
				'attr'			=> 'color',
				'type'			=> 'select',
				'options'		=> array(
					'alt'		=> __( 'Mako', 'zerofour' ),
					'blue'		=> __( 'Boston Blue', 'zerofour' )
				)
			),
			array(
				'label'			=> __( 'Button Size', 'zerofour' ),
				'attr'			=> 'size',
				'type'			=> 'select',
				'options'		=> array(
					'medium'	=> __( 'Large', 'zerofour' ),
					'small'		=> __( 'Small', 'zerofour' )
				)
			)
		);

		$settings = array(
			'label'			=> __( 'Button', 'zerofour' ),
			'listItemImage'	=> 'dashicons-plus-alt',
			'post_type'		=> array( 'post', 'page' ),
			'attrs'			=> $fields
		);

		shortcode_ui_register_for_shortcode( 'zf_button', $settings );
	}
	add_action( 'register_shortcode_ui', 'zerofour_btn_shortcode_reg' );