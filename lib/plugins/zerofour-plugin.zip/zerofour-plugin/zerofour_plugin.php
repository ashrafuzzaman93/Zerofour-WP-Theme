<?php

	/*
	Plugin Name:  Zerofour Theme Plugin
	Plugin URI:   https://github.com/asrafuzzaman
	Description:  The Plugin required for Zerofour theme.
	Version:      1.0.0
	Author:       Ashrafuzzaman
	Author URI:   http://ashrafuzzaman.com
	License:      GPL2
	License URI:  https://www.gnu.org/licenses/gpl-2.0.html
	Text Domain:  zerofour_plugin
	Domain Path:  /languages
	*/


	/* -------------------------------------------------------------------- */
	/* Custom post type register for zerofour services posts */
	/* -------------------------------------------------------------------- */

	function zerofour_register_cpt_services() {

	/**
	 * Post Type: Services.
	 */

		$labels = array(
			"name" => __( "Services", "zerofour" ),
			"singular_name" => __( "Service", "zerofour" ),
			"all_items" => __( "All Services", "zerofour" ),
			"add_new" => __( "Add Service", "zerofour" ),
			"add_new_item" => __( "Add New Service", "zerofour" ),
			"edit_item" => __( "Edit Service", "zerofour" ),
			"new_item" => __( "New Service", "zerofour" ),
			"view_item" => __( "View Service", "zerofour" ),
			"view_items" => __( "View Services", "zerofour" ),
			"search_items" => __( "Search Service", "zerofour" ),
			"not_found" => __( "No Services found", "zerofour" ),
			"not_found_in_trash" => __( "No Services found in Trash", "zerofour" ),
			"featured_image" => __( "Service image", "zerofour" ),
			"set_featured_image" => __( "Set service image", "zerofour" ),
			"remove_featured_image" => __( "Remove service image", "zerofour" ),
			"use_featured_image" => __( "Use as service image", "zerofour" ),
			"archives" => __( "Service archives", "zerofour" ),
			"name_admin_bar" => __( "Service", "zerofour" ),
		);

		$args = array(
			"label" => __( "Services", "zerofour" ),
			"labels" => $labels,
			"description" => "",
			"public" => true,
			"publicly_queryable" => true,
			"show_ui" => true,
			"delete_with_user" => false,
			"show_in_rest" => true,
			"rest_base" => "",
			"rest_controller_class" => "WP_REST_Posts_Controller",
			"has_archive" => false,
			"show_in_menu" => true,
			"show_in_nav_menus" => true,
			"exclude_from_search" => false,
			"capability_type" => "post",
			"map_meta_cap" => true,
			"hierarchical" => false,
			"rewrite" => array( "slug" => "services", "with_front" => true ),
			"query_var" => true,
			"menu_position" => 22,
			"menu_icon" => "dashicons-admin-generic",
			"supports" => array( "title", "editor", "thumbnail" ),
		);

		register_post_type( "services", $args );
	}

	add_action( 'init', 'zerofour_register_cpt_services' );



	/* ----------------------------------------------------- */
	/* Zerofour Theme Button Shortcode */
	/* ----------------------------------------------------- */

	function zerofour_button_shortcode( $attr ) {

		$zf_defaults_attr = array(
			'url'		=> '#',
			'text'		=> __( 'Button', 'zerofour' ),
			'icon'		=> 'fa-info-circle',
			'target'	=> '_self',
			'color'		=> '',
			'size'		=> ''
		);

		$zf_def_btn_params = shortcode_atts( $zf_defaults_attr, $attr );

		return '<a href="'. $zf_def_btn_params['url'] .'" class="button '. $zf_def_btn_params['size'] .' '. $zf_def_btn_params['color'] .' icon '. $zf_def_btn_params['icon'] .'" target="'. $zf_def_btn_params['target'] .'">'. $zf_def_btn_params['text'] .'</a>';
	}
	add_shortcode( 'zf_button', 'zerofour_button_shortcode' );

	require_once( dirname(__FILE__).'/zerofour_shortcode_ui.php' );






